# DAY 6 - ACTIVITY 2
# This is the module for computing the gross salary.
# Every hour, the employee earns 500

def gross ( hour ):
    grossSalary = hour * 500
    return grossSalary
