# DAY 6 - ACTIVITY 2
# This is a module that computes for the employees net salary.

def net ( grossSalary, totalDeductions ):
    netSalary = grossSalary - totalDeductions
    return netSalary
